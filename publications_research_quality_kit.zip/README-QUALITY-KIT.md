# Publications research quality kit

## Suggested folder structure

- `manuscripts/drafts/` — working Word manuscripts
- `manuscripts/submitted/` — submitted versions, if you choose to track them
- `manuscripts/final/` — approved versions for publication
- `sources/` — only sources you are entitled to store and share
- `bibliography/references.csv` — structured bibliography register
- `research-notes/claim-verification.csv` — register of claims that require source verification
- `scripts/check_research.py` — basic technical checks
- `.github/workflows/research-quality.yml` — runs checks on pushes, pull requests, and manual dispatch

## How to use it

1. Put `.docx` manuscripts under `manuscripts/`.
2. Replace the example row in `bibliography/references.csv` with your real reference records.
3. Replace the example row in `research-notes/claim-verification.csv` with claims that need verification.
4. Commit the files and open the **Actions** tab.
5. Open the `Research quality checks` workflow run to read its output.

## Verification status values

Bibliography `verification_status`:
- `not_checked`
- `checked`
- `needs_review`
- `not_applicable`

Claim register `verification_status`:
- `not_checked`
- `verified`
- `needs_review`
- `not_applicable`

Use `verified` only after a person has checked the primary or otherwise authoritative source and confirmed that it supports the claim.

## Important limitations

These checks validate file readability and register structure. They do not prove that citations exist, that legal authorities remain good law, that a quotation is exact, or that a source supports a proposition. Do not treat a passing workflow as legal sign-off.

Do not commit privileged material, client-confidential information, personal data, access tokens, or any document that you are not authorized to store in this repository.
