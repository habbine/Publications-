# Manuscript drafts

Place approved-to-store Word `.docx` drafts in this folder. Do not commit confidential client material.
