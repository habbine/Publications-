#!/usr/bin/env python3
"""Basic structural checks for Word manuscripts and research registers.

This script does NOT verify that a legal authority exists or supports a proposition.
It checks document readability and the structure/completeness of CSV registers.
"""
from pathlib import Path
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
ERRORS = []
WARNINGS = []

def error(message):
    ERRORS.append(message)
    print(f"ERROR: {message}")

def warning(message):
    WARNINGS.append(message)
    print(f"WARNING: {message}")

def read_csv(path, required_columns):
    if not path.exists():
        warning(f"{path.relative_to(ROOT)} not found; skipping.")
        return []
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            headers = set(reader.fieldnames or [])
            missing = set(required_columns) - headers
            if missing:
                error(f"{path.relative_to(ROOT)} missing columns: {', '.join(sorted(missing))}")
                return []
            return list(reader)
    except Exception as exc:
        error(f"Cannot read {path.relative_to(ROOT)}: {exc}")
        return []

def check_manuscripts():
    folder = ROOT / "manuscripts"
    docs = sorted(folder.rglob("*.docx")) if folder.exists() else []
    if not docs:
        warning("No .docx files found under manuscripts/. Add a test manuscript to exercise this check.")
        return

    try:
        from docx import Document
    except ImportError:
        error("python-docx is not installed.")
        return

    for path in docs:
        rel = path.relative_to(ROOT)
        if path.name.startswith("~$"):
            warning(f"{rel}: appears to be a temporary Microsoft Word lock file; do not commit it.")
            continue
        try:
            doc = Document(str(path))
            paragraphs = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
            if not paragraphs:
                error(f"{rel}: document contains no readable paragraph text.")
                continue

            headings = [p for p in doc.paragraphs if p.style and p.style.name.lower().startswith("heading")]
            if not headings:
                warning(f"{rel}: no Word Heading styles detected. Use Heading 1/2/3 for section structure.")

            full_text = "\n".join(paragraphs).lower()
            placeholders = ["[insert citation]", "[citation needed]", "todo:", "tbd"]
            for marker in placeholders:
                if marker in full_text:
                    warning(f"{rel}: placeholder text found: {marker}")

            if len(" ".join(paragraphs).split()) < 100:
                warning(f"{rel}: fewer than 100 words; check whether this is a complete manuscript or a test file.")

            print(f"PASS: {rel} ({len(' '.join(paragraphs).split())} words; {len(headings)} styled headings)")
        except Exception as exc:
            error(f"{rel}: cannot read as a valid .docx file ({exc}).")

def check_bibliography():
    path = ROOT / "bibliography" / "references.csv"
    rows = read_csv(path, ["reference_id", "type", "title", "year", "source", "doi", "url", "verification_status"])
    seen_ids = set()
    seen_dois = set()
    allowed_status = {"not_checked", "checked", "needs_review", "not_applicable"}

    for i, row in enumerate(rows, start=2):
        rid = (row.get("reference_id") or "").strip()
        doi = (row.get("doi") or "").strip().lower().removeprefix("https://doi.org/").removeprefix("http://doi.org/")
        if not rid:
            error(f"bibliography/references.csv row {i}: reference_id is empty.")
        elif rid in seen_ids:
            error(f"bibliography/references.csv row {i}: duplicate reference_id '{rid}'.")
        seen_ids.add(rid)

        if not (row.get("title") or "").strip():
            warning(f"bibliography/references.csv row {i} ({rid or 'no ID'}): title is empty.")
        if not (row.get("year") or "").strip():
            warning(f"bibliography/references.csv row {i} ({rid or 'no ID'}): year is empty.")
        if doi:
            if doi in seen_dois:
                error(f"bibliography/references.csv row {i}: duplicate DOI '{doi}'.")
            seen_dois.add(doi)

        status = (row.get("verification_status") or "").strip().lower()
        if status and status not in allowed_status:
            error(f"bibliography/references.csv row {i}: invalid verification_status '{status}'. Use {', '.join(sorted(allowed_status))}.")

    if rows:
        print(f"PASS: bibliography/references.csv ({len(rows)} records checked)")

def check_claim_register():
    path = ROOT / "research-notes" / "claim-verification.csv"
    rows = read_csv(path, ["claim_id", "claim", "source_reference_id", "source_locator", "verification_status"])
    allowed = {"not_checked", "verified", "needs_review", "not_applicable"}
    for i, row in enumerate(rows, start=2):
        cid = (row.get("claim_id") or "").strip() or f"row {i}"
        if not (row.get("claim") or "").strip():
            warning(f"claim-verification.csv {cid}: claim text is empty.")
        if not (row.get("source_reference_id") or "").strip():
            warning(f"claim-verification.csv {cid}: no source_reference_id recorded.")
        if not (row.get("source_locator") or "").strip():
            warning(f"claim-verification.csv {cid}: no page, paragraph, article, docket number, or other locator recorded.")
        status = (row.get("verification_status") or "").strip().lower()
        if status and status not in allowed:
            error(f"claim-verification.csv {cid}: invalid verification_status '{status}'. Use {', '.join(sorted(allowed))}.")
    if rows:
        print(f"PASS: research-notes/claim-verification.csv ({len(rows)} claims reviewed structurally)")

def main():
    print("Running basic publication-quality checks...")
    check_manuscripts()
    check_bibliography()
    check_claim_register()
    print(f"\nFinished: {len(ERRORS)} error(s), {len(WARNINGS)} warning(s).")
    if ERRORS:
        sys.exit(1)
    print("Technical checks passed. This does not certify legal or factual accuracy.")

if __name__ == "__main__":
    main()
